     ___.         ___.        .___           __    .___         .___      
______\_ |__   ____\_ |__    __| _/____      |__| __| _/____   __| _/____  
\_  __ \ __ \_/ __ \| __ \  / __ |\__  \     |  |/ __ |/  _ \ / __ |/  _ \ 
 |  | \/ \_\ \  ___/| \_\ \/ /_/ | / __ \_   |  / /_/ (  <_> ) /_/ (  <_> )
 |__|  |___  /\___  >___  /\____ |(____  /\__|  \____ |\____/\____ |\____/ 
           \/     \/    \/      \/     \/\______|    \/           \/       

Creator: 14anz

type of malware: GDI trojan

range:Destructive (for non-safety)

created it using maltoolkit lmao

this malware was my first btw. the dangerous version will delete system DLLS and make a bunch of accounts and shi (prob). im not responsible for any damages made using this malware

it contains flashing lights!!!!!!

